package com.example.seleniumfirstdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeleniumFirstDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeleniumFirstDemoApplication.class, args);
	}

}
